//
//  URLHelper.h
//  RSS Reader
//
//  Created by Mateusz Bajer on 10.07.08.
//  Copyright 2010 ANTiSoftware. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface URLHelper : NSObject {
}

+ (NSString *)standarizeStringToURL:(NSString *)urlString;

@end
