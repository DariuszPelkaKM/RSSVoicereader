//
//  TabBarController.h
//  RSS Reader
//
//  Created by Mateusz Bajer on 2.06.19.
//  Copyright 2010 ANTiSoftware. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface TabBarController : UITabBarController {

}

@end
